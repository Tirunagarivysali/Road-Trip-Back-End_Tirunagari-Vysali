<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname="road trip";

// Create connection
$conn = mysqli_connect($servername, $username, $password,$dbname);

// Check connection
if (!$conn) {
  die("Connection failed: " . mysqli_connect_error());
}
if(isset($_POST['rating']) and isset($_POST['name']) and isset($_POST['comments']))
{
  $rate=$_POST['rating'];
  $pname=$_POST['name'];
  $pcomments=$_POST['comments'];
  $sql="INSERT INTO tfeedback (trate,tname,tcomments)  values ('$rate','$pname','$pcomments')";
  if(mysqli_query($conn,$sql))
  {
    echo "I appreciate you in investing time for improving us.Thank you ".$pname;
  }
  else{
    echo "Error in uploading feedback details";
  }
}
mysqli_close($conn);
 ?>
